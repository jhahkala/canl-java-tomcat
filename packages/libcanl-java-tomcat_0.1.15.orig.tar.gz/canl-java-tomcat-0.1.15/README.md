EMI Common Authentication Library Tomcat plugin
===============================================

Java library that allows the use of EMI common authentication library in Tomcat.