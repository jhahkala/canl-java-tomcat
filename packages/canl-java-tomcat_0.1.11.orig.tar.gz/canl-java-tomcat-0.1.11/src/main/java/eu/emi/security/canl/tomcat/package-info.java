/**
 * The Common AutheNtication Library Tomcat integration classes.
 * 
 */
package eu.emi.security.canl.tomcat;
